import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCart } from '../store/slices/cartSlice';

const ProductCard = ({ product }) => {
  const dispatch = useDispatch();
  const inStock = product.stockCount > 0;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
      <Link to={`/product/${product._id}`}>
        <img
          src={product.images?.[0]?.url || 'https://via.placeholder.com/300'}
          alt={product.title}
          className="h-48 w-full object-cover"
        />
      </Link>
      <div className="p-4">
        <Link to={`/product/${product._id}`} className="text-lg font-semibold text-gray-800 hover:text-brand-700">
          {product.title}
        </Link>
        <p className="text-sm text-gray-500 mt-1 capitalize">{product.category}</p>
        <div className="flex items-center justify-between mt-3">
          <span className="text-brand-700 font-bold text-xl">
            ₦{product.price.toLocaleString()}
          </span>
          <span className={`text-xs font-medium ${inStock ? 'text-green-600' : 'text-red-500'}`}>
            {inStock ? `${product.stockCount} in stock` : 'Out of stock'}
          </span>
        </div>
        {inStock ? (
          <button
            onClick={() => dispatch(addToCart({ ...product, quantity: 1 }))}
            className="mt-4 w-full bg-brand-500 text-white py-2 rounded-md hover:bg-brand-700 transition"
          >
            Add to Cart
          </button>
        ) : (
          <button disabled className="mt-4 w-full bg-gray-300 text-gray-600 py-2 rounded-md cursor-not-allowed">
            Out of Stock
          </button>
        )}
      </div>
    </div>
  );
};

export default ProductCard;