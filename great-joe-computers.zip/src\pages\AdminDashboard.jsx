import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import axios from 'axios';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const { user } = useSelector((state) => state.auth);
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [ordRes, prodRes] = await Promise.all([
          axios.get('http://localhost:5000/api/orders/admin', { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('http://localhost:5000/api/products'),
        ]);
        setOrders(ordRes.data.data);
        setProducts(prodRes.data.data);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [token]);

  const totalRevenue = orders
    .filter((o) => o.paymentStatus === 'paid')
    .reduce((sum, o) => sum + o.totalPrice, 0);

  const totalOrders = orders.length;
  const pendingOrders = orders.filter((o) => o.paymentStatus === 'pending').length;

  if (loading) return <div className="p-10">Loading dashboard...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-lg shadow">
          <p className="text-gray-500 text-sm">Total Revenue</p>
          <p className="text-2xl font-bold text-brand-700">₦{totalRevenue.toLocaleString()}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <p className="text-gray-500 text-sm">Total Orders</p>
          <p className="text-2xl font-bold">{totalOrders}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <p className="text-gray-500 text-sm">Pending Payments</p>
          <p className="text-2xl font-bold text-orange-500">{pendingOrders}</p>
        </div>
      </div>

      {/* Product Management */}
      <div className="mb-10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Products ({products.length})</h2>
          <Link to="/admin/products/new" className="bg-brand-500 text-white px-4 py-2 rounded-md hover:bg-brand-700">
            + New Product
          </Link>
        </div>
        <div className="bg-white rounded-lg shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left">Title</th>
                <th className="px-4 py-2 text-left">Category</th>
                <th className="px-4 py-2 text-left">Price (₦)</th>
                <th className="px-4 py-2 text-left">Stock</th>
                <th className="px-4 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p._id} className="border-b">
                  <td className="px-4 py-2">{p.title}</td>
                  <td className="px-4 py-2">{p.category}</td>
                  <td className="px-4 py-2">{p.price.toLocaleString()}</td>
                  <td className="px-4 py-2">{p.stockCount}</td>
                  <td className="px-4 py-2 space-x-2">
                    <Link to={`/admin/products/edit/${p._id}`} className="text-blue-600 hover:underline">Edit</Link>
                    <button
                      onClick={async () => {
                        if (window.confirm('Delete product?')) {
                          await axios.delete(`http://localhost:5000/api/products/${p._id}`, { headers: { Authorization: `Bearer ${token}` } });
                          setProducts(products.filter((prod) => prod._id !== p._id));
                        }
                      }}
                      className="text-red-600 hover:underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Orders */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Recent Orders</h2>
        <div className="bg-white rounded-lg shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left">Order ID</th>
                <th className="px-4 py-2 text-left">Customer</th>
                <th className="px-4 py-2 text-left">Total</th>
                <th className="px-4 py-2 text-left">Payment</th>
                <th className="px-4 py-2 text-left">Delivery</th>
              </tr>
            </thead>
            <tbody>
              {orders.slice(0, 10).map((order) => (
                <tr key={order._id} className="border-b">
                  <td className="px-4 py-2 font-mono text-xs">{order._id}</td>
                  <td className="px-4 py-2">{order.user?.name || 'N/A'}</td>
                  <td className="px-4 py-2">₦{order.totalPrice.toLocaleString()}</td>
                  <td className="px-4 py-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      order.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' :
                      order.paymentStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                    }`}>{order.paymentStatus}</span>
                  </td>
                  <td className="px-4 py-2 capitalize">{order.deliveryStatus}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;