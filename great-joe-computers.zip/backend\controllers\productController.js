import Product from '../models/Product.js';
import { cloudinary } from '../config/cloudinary.js';

// @desc    Create product (admin only)
// @route   POST /api/products
export const createProduct = async (req, res, next) => {
  try {
    const images = req.files
      ? req.files.map((file) => ({ url: file.path, public_id: file.filename }))
      : [];
    const product = await Product.create({ ...req.body, images });
    res.status(201).json({ success: true, data: product });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all products with filters
// @route   GET /api/products
export const getProducts = async (req, res, next) => {
  try {
    const { category, minPrice, maxPrice, search, inStock } = req.query;
    const filter = {};

    if (category) filter.category = category;
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }
    if (search) {
      filter.title = { $regex: search, $options: 'i' };
    }
    if (inStock === 'true') {
      filter.stockCount = { $gt: 0 };
    }

    const products = await Product.find(filter);
    res.json({ success: true, count: products.length, data: products });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single product
// @route   GET /api/products/:id
export const getProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    res.json({ success: true, data: product });
  } catch (error) {
    next(error);
  }
};

// @desc    Update product (admin only)
// @route   PUT /api/products/:id
export const updateProduct = async (req, res, next) => {
  try {
    let product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    // Handle new image uploads
    if (req.files && req.files.length > 0) {
      // Delete old images from cloudinary
      for (const img of product.images) {
        await cloudinary.uploader.destroy(img.public_id);
      }
      req.body.images = req.files.map((file) => ({
        url: file.path,
        public_id: file.filename,
      }));
    }
    product = await Product.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    res.json({ success: true, data: product });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete product (admin only)
// @route   DELETE /api/products/:id
export const deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }
    // Remove images from cloudinary
    for (const img of product.images) {
      await cloudinary.uploader.destroy(img.public_id);
    }
    await product.deleteOne();
    res.json({ success: true, data: {} });
  } catch (error) {
    next(error);
  }
};