import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts } from '../store/slices/productSlice';
import ProductCard from '../components/ProductCard';
import { Link } from 'react-router-dom';

const Home = () => {
  const dispatch = useDispatch();
  const { items, loading } = useSelector((state) => state.products);

  useEffect(() => {
    dispatch(fetchProducts({}));
  }, [dispatch]);

  const featured = items.slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-r from-brand-700 to-brand-500 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4">
            Premium Tech, Unbeatable Deals
          </h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8">
            Shop high-performance computers, components, and accessories – delivered across Nigeria.
          </p>
          <Link
            to="/catalog"
            className="inline-block bg-white text-brand-700 font-semibold px-8 py-3 rounded-full hover:bg-gray-100 transition"
          >
            Explore Catalog
          </Link>
        </div>
      </section>

      {/* Category Grid */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-gray-800 mb-8">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {['Laptops', 'Desktops', 'Accessories', 'Components'].map((cat) => (
            <Link
              key={cat}
              to={`/catalog?category=${cat}`}
              className="bg-white border rounded-lg p-6 text-center hover:shadow-md transition"
            >
              <div className="text-brand-700 font-bold text-xl mb-2">{cat}</div>
              <p className="text-sm text-gray-500">View all</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-8">Featured Tech</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

export default Home;